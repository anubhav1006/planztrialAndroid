package com.planzappdemo.Constants;

public class PlanzConstants {
    public static final String url = "localhost:8080/";
}
